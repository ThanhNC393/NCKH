cd nckh && pip install -e .
